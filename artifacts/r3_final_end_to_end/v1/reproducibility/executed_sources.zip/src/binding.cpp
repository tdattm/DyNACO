/**
 * pybind11 bindings for Unified MFACO Training Module
 *
 * Exposes MFACO_TSP, MFACO_CVRP, and MFACOTrace to Python.
 * Module name: faco_opt
 */

#include "mfaco_train.h"
#include <omp.h>
#include <mutex>
#include <pybind11/numpy.h>
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;
using namespace mfaco;

// ============================================================================
// Helper: create numpy array view from vector (no copy)
// ============================================================================

template <typename T>
py::array_t<T> make_view(T *data, std::vector<py::ssize_t> shape) {
  // Compute strides (row-major)
  std::vector<py::ssize_t> strides(shape.size());
  py::ssize_t stride = sizeof(T);
  for (int i = static_cast<int>(shape.size()) - 1; i >= 0; --i) {
    strides[i] = stride;
    stride *= shape[i];
  }
  return py::array_t<T>(shape, strides, data, py::none());
}

template <typename T> py::array_t<T> make_1d_view(T *data, py::ssize_t len) {
  return make_view<T>(data, {len});
}

template <typename T>
py::array_t<T> make_2d_view(T *data, py::ssize_t rows, py::ssize_t cols) {
  return make_view<T>(data, {rows, cols});
}

// ============================================================================
// MFACOTraceBatch Python wrapper (Shared)
// ============================================================================

class PyMFACOTrace {
public:
  // The trace batch from C++
  MFACOTraceBatch batch;
  int32_t n_ants;

  PyMFACOTrace() : n_ants(0) {}

  // Property accessors returning numpy views
  py::array_t<int32_t> get_starts() {
    return make_1d_view(batch.starts.data(), batch.starts.size());
  }

  py::array_t<int32_t> get_curr_nodes() {
    return make_1d_view(batch.curr_nodes.data(), batch.curr_nodes.size());
  }

  py::array_t<int32_t> get_chosen_nodes() {
    return make_1d_view(batch.chosen_nodes.data(), batch.chosen_nodes.size());
  }

  py::array_t<uint8_t> get_is_stochastic() {
    return make_1d_view(batch.is_stochastic.data(), batch.is_stochastic.size());
  }

  py::array_t<int16_t> get_pick_j() {
    return make_1d_view(batch.pick_j.data(), batch.pick_j.size());
  }

  py::array_t<uint64_t> get_valid_mask() {
    return make_1d_view(batch.valid_mask.data(), batch.valid_mask.size());
  }

  py::array_t<uint8_t> get_is_new_edge() {
    return make_1d_view(batch.is_new_edge.data(), batch.is_new_edge.size());
  }

  py::array_t<int32_t> get_start_nodes() {
    return make_1d_view(batch.start_nodes.data(), batch.start_nodes.size());
  }

  int32_t n_decisions() const {
    return static_cast<int32_t>(batch.curr_nodes.size());
  }

  // Convert batch to list of Python-compatible trace dicts for
  // replay_logp_batch
  py::list to_trace_list() {
    py::list result;
    for (int32_t a = 0; a < n_ants; ++a) {
      py::dict trace;
      trace["start_node"] = batch.start_nodes[a];

      int32_t start = batch.starts[a];
      int32_t end = batch.starts[a + 1];

      py::list curr, chosen, is_stoch;
      for (int32_t i = start; i < end; ++i) {
        curr.append(batch.curr_nodes[i]);
        chosen.append(batch.chosen_nodes[i]);
        is_stoch.append(batch.is_stochastic[i] != 0);
      }

      trace["curr_nodes"] = curr;
      trace["chosen_nodes"] = chosen;
      trace["is_stochastic"] = is_stoch;
      trace["is_new_edge"] =
          make_1d_view(batch.is_new_edge.data() + start, end - start);

      result.append(trace);
    }
    return result;
  }
};

// ============================================================================
// MFACO_TSP Python wrapper
// ============================================================================

class PyMFACO_TSP {
public:
  std::unique_ptr<MFACO_TSP> solver;
  std::mutex ls_mutex;

  void set_ls_widths(const std::vector<int32_t> &widths) {
    std::lock_guard<std::mutex> lock(ls_mutex);
    solver->set_ls_widths(widths);
  }
  void enable_ls_counts(bool enabled) {
    std::lock_guard<std::mutex> lock(ls_mutex);
    solver->enable_ls_counts(enabled);
  }
  py::dict get_ls_state() {
    std::lock_guard<std::mutex> lock(ls_mutex);
    py::dict d;
    d["widths"] = solver->ls_widths();
    d["candidates"] = solver->ls_candidates();
    return d;
  }
  py::dict get_ls_counts() {
    std::lock_guard<std::mutex> lock(ls_mutex);
    auto c = solver->get_ls_counts(); py::dict d;
    d["calls"] = c.calls; d["candidates"] = c.candidates;
    d["expanded_candidates"] = c.expanded_candidates;
    d["gains"] = c.gains; d["expanded_gains"] = c.expanded_gains;
    d["accepted"] = c.accepted; d["expanded_accepted"] = c.expanded_accepted;
    return d;
  }

  PyMFACO_TSP(
      py::array_t<float, py::array::c_style | py::array::forcecast> coords,
      int32_t n_ants, int32_t cand_list_size = 32,
      int32_t backup_list_size = 32, int32_t min_new_edges = 8,
      float decay = 0.9f, float alpha = 1.0f, float p_best = 0.05f,
      bool use_local_search = true, bool disable_heuristic = false,

      bool extend_ls = false, bool smooth_mmas = false, int32_t fixed_steps = 0,
      bool nls = false, int32_t T_nls = 10) {
    auto buf = coords.request();
    if (buf.ndim != 2 || buf.shape[1] != 2) {
      throw std::runtime_error("coords must have shape (n, 2)");
    }
    int32_t n = static_cast<int32_t>(buf.shape[0]);
    const float *coords_ptr = static_cast<const float *>(buf.ptr);

    solver = std::make_unique<MFACO_TSP>(
        coords_ptr, n, n_ants, cand_list_size, backup_list_size, min_new_edges,
        decay, alpha, p_best, use_local_search, disable_heuristic, extend_ls,
        smooth_mmas, fixed_steps, nls, T_nls);
  }

  // Properties
  int32_t get_n() const { return solver->n; }
  int32_t get_n_ants() const { return solver->n_ants; }
  int32_t get_k() const { return solver->k; }
  int32_t get_bl() const { return solver->bl; }
  int32_t get_min_new_edges() const { return solver->min_new_edges; }
  int32_t get_fixed_steps() const { return solver->fixed_steps; }
  float get_rho() const { return solver->rho; }
  float get_alpha() const { return solver->alpha; }
  float get_p_best() const { return solver->p_best; }
  bool get_use_local_search() const { return solver->use_local_search; }
  bool get_extend_ls() const { return solver->extend_ls; }
  bool get_smooth_mmas() const { return solver->smooth_mmas; }
  float get_source_cost() const { return solver->source_cost; }
  float get_best_cost() const { return solver->best_cost; }
  float get_tau_min() const { return solver->tau_min; }
  float get_tau_max() const { return solver->tau_max; }

  py::array_t<float> get_pheromone_sparse_np() {
    return make_2d_view(solver->pheromone_data(), solver->n, solver->k);
  }
  py::array_t<int32_t> get_nn_list() {
    return make_2d_view(solver->nn_list_data(), solver->n, solver->k);
  }
  py::array_t<int32_t> get_backup_list() {
    return make_2d_view(solver->backup_list_data(), solver->n, solver->bl);
  }
  py::array_t<float> get_heuristic_sparse_np() {
    return make_2d_view(solver->heuristic_data(), solver->n, solver->k);
  }
  py::array_t<int32_t> get_source_route() {
    return make_1d_view(solver->source_route_data(), solver->n);
  }
  py::array_t<int32_t> get_best_route() {
    return make_1d_view(solver->best_route_data(), solver->n);
  }
  // py::array_t<int32_t> get_nn_pos() { ... } REMOVED
  py::array_t<int32_t> get_source_positions() {
    return make_1d_view(solver->source_positions.data(), solver->n);
  }

  void seed_rng(uint64_t seed) { solver->seed_rng(seed); }

  py::tuple
  sample(float invtemp = 1.0f, // unused for now, heuristic is pre-baked
         bool require_prob = false, py::object prior_obj = py::none(),
         bool parallel_traced = false) {
    const float *prior_ptr = nullptr;
    py::array_t<float> prior_arr;

    if (!prior_obj.is_none()) {
      prior_arr = prior_obj.cast<
          py::array_t<float, py::array::c_style | py::array::forcecast>>();
      auto buf = prior_arr.request();
      if (buf.ndim != 2 || buf.shape[0] != solver->n ||
          buf.shape[1] != solver->k) {
        throw std::runtime_error("prior must be shape (n, k)");
      }
      prior_ptr = static_cast<const float *>(buf.ptr);
    }

    SampleResult result;
    {
      py::gil_scoped_release release;
      std::lock_guard<std::mutex> lock(ls_mutex);
      solver->sample(require_prob, prior_ptr, result, parallel_traced);
    }

    py::array_t<float> costs(solver->n_ants);
    auto costs_buf = costs.mutable_unchecked<1>();
    for (int32_t a = 0; a < solver->n_ants; ++a)
      costs_buf(a) = result.costs[a];

    py::list flats;
    for (int32_t a = 0; a < solver->n_ants; ++a) {
      py::array_t<int32_t> flat(solver->n + 1);
      auto flat_buf = flat.mutable_unchecked<1>();
      for (int32_t i = 0; i < solver->n; ++i)
        flat_buf(i) = result.routes[a][i];
      flat_buf(solver->n) = result.routes[a][0];
      flats.append(flat);
    }

    py::list touched_list;
    for (int32_t a = 0; a < solver->n_ants; ++a)
      touched_list.append(make_1d_view<int32_t>(nullptr, 0));

    py::object traces_obj = py::none();
    if (require_prob) {
      auto traces = std::make_unique<PyMFACOTrace>();
      traces->batch = std::move(result.traces);
      traces->n_ants = solver->n_ants;
      traces_obj = py::cast(std::move(traces));
    }

    py::array_t<float> logps_arr(solver->n_ants);
    if (!result.logps.empty()) {
      auto logps_buf = logps_arr.mutable_unchecked<1>();
      for (int32_t a = 0; a < solver->n_ants; ++a)
        logps_buf(a) = result.logps[a];
    }

    py::object costs_raw_obj = py::none();
    if (!result.costs_raw.empty()) {
      py::array_t<float> costs_raw_arr(solver->n_ants);
      auto buf = costs_raw_arr.mutable_unchecked<1>();
      for (int32_t a = 0; a < solver->n_ants; ++a)
        buf(a) = result.costs_raw[a];
      costs_raw_obj = costs_raw_arr;
    }

    py::object flats_raw_obj = py::none();
    if (!result.routes_raw.empty()) {
      py::list flats_raw;
      for (int32_t a = 0; a < solver->n_ants; ++a) {
        py::array_t<int32_t> flat(solver->n + 1);
        auto flat_buf = flat.mutable_unchecked<1>();
        for (int32_t i = 0; i < solver->n; ++i)
          flat_buf(i) = result.routes_raw[a][i];
        flat_buf(solver->n) = result.routes_raw[a][0];
        flats_raw.append(flat);
      }
      flats_raw_obj = flats_raw;
    }

    py::array_t<int32_t> new_edges_arr(solver->n_ants);
    auto ne_buf = new_edges_arr.mutable_unchecked<1>();
    if (!result.new_edges_count.empty()) {
      for (int32_t a = 0; a < solver->n_ants; ++a)
        ne_buf(a) = result.new_edges_count[a];
    } else {
      for (int32_t a = 0; a < solver->n_ants; ++a)
        ne_buf(a) = 0;
    }

    py::array_t<float> survival_arr(solver->n_ants);
    auto surv_buf = survival_arr.mutable_unchecked<1>();
    if (!result.edge_survival.empty()) {
      for (int32_t a = 0; a < solver->n_ants; ++a)
        surv_buf(a) = result.edge_survival[a];
    } else {
      for (int32_t a = 0; a < solver->n_ants; ++a)
        surv_buf(a) = 0.0f;
    }

    return py::make_tuple(costs, flats, touched_list, logps_arr, traces_obj,
                          costs_raw_obj, flats_raw_obj, new_edges_arr,
                          survival_arr);
  }

  void update_pheromone_from_flat(
      py::array_t<int32_t, py::array::c_style | py::array::forcecast> best_flat,
      float best_cost) {
    auto buf = best_flat.request();
    if (buf.ndim != 1 || buf.shape[0] < solver->n) {
      throw std::runtime_error("best_flat must be at least length n");
    }
    const int32_t *flat_ptr = static_cast<const int32_t *>(buf.ptr);
    py::gil_scoped_release release;
    solver->update_pheromone(flat_ptr, best_cost);
  }

  void load_snapshot(
      py::array_t<float, py::array::c_style | py::array::forcecast> pheromone,
      py::array_t<int32_t, py::array::c_style | py::array::forcecast>
          source_route,
      float source_cost,
      py::array_t<int32_t, py::array::c_style | py::array::forcecast>
          best_route,
      float best_cost, float tau_min, float tau_max,
      py::array_t<int32_t, py::array::c_style | py::array::forcecast> nn_list,
      py::array_t<int32_t, py::array::c_style | py::array::forcecast>
          backup_list) {
    auto phe_buf = pheromone.request();
    auto src_buf = source_route.request();
    auto best_buf = best_route.request();
    auto nn_buf = nn_list.request();
    auto bl_buf = backup_list.request();

    solver->load_snapshot(
        static_cast<const float *>(phe_buf.ptr),
        static_cast<const int32_t *>(src_buf.ptr), source_cost,
        static_cast<const int32_t *>(best_buf.ptr), best_cost, tau_min, tau_max,
        static_cast<const int32_t *>(nn_buf.ptr),
        static_cast<const int32_t *>(bl_buf.ptr));
  }

  void set_pheromone(
      py::array_t<float, py::array::c_style | py::array::forcecast> pheromone) {
    auto buf = pheromone.request();
    solver->set_pheromone(static_cast<const float *>(buf.ptr));
  }

  void sync_pheromone_to_torch() {
    // No-op
  }
};

// ============================================================================
// MFACO_CVRP Python wrapper
// ============================================================================

class PyMFACO_CVRP {
public:
  std::unique_ptr<MFACO_CVRP> solver;

  PyMFACO_CVRP(py::array_t<float, py::array::c_style | py::array::forcecast>
                   coords, // (n,2)
               py::array_t<float, py::array::c_style | py::array::forcecast>
                   demand, // (n,)
               float capacity, int32_t n_ants, int32_t cand_list_size = 32,
               int32_t backup_list_size = 32, int32_t min_new_edges = 8,
               float decay = 0.9f, float alpha = 1.0f, float p_best = 0.05f,
               bool use_local_search = true, bool disable_heuristic = false,

               bool extend_ls = false, bool smooth_mmas = false,
               int32_t fixed_steps = 0, bool nls = false, int32_t T_nls = 10) {
    auto cbuf = coords.request();
    if (cbuf.ndim != 2 || cbuf.shape[1] != 2) {
      throw std::runtime_error("coords must be shape (n,2)");
    }
    int32_t n = (int32_t)cbuf.shape[0];

    auto dbuf = demand.request();
    if (dbuf.ndim != 1 || (int32_t)dbuf.shape[0] != n) {
      throw std::runtime_error("demand must be shape (n,) matching coords");
    }

    solver = std::make_unique<MFACO_CVRP>(
        (const float *)cbuf.ptr, (const float *)dbuf.ptr, n, capacity, n_ants,
        cand_list_size, backup_list_size, min_new_edges, decay, alpha, p_best,
        use_local_search, disable_heuristic, extend_ls, smooth_mmas,
        fixed_steps, nls, T_nls);
  }

  // properties
  int32_t get_n() const { return solver->n; }
  int32_t get_m() const { return solver->m; }
  int32_t get_n_ants() const { return solver->n_ants; }
  int32_t get_k() const { return solver->k; }
  int32_t get_bl() const { return solver->bl; }
  float get_source_cost() const { return solver->source_cost; }
  float get_best_cost() const { return solver->best_cost; }
  float get_tau_min() const { return solver->tau_min; }
  float get_tau_max() const { return solver->tau_max; }

  py::array_t<float> get_pheromone_sparse_np() {
    return make_2d_view(solver->pheromone_data(), solver->n, solver->k);
  }
  py::array_t<int32_t> get_nn_list() {
    return make_2d_view(solver->nn_list_data(), solver->n, solver->k);
  }
  py::array_t<int32_t> get_backup_list() {
    return make_2d_view(solver->backup_list_data(), solver->n, solver->bl);
  }
  py::array_t<float> get_heuristic_sparse_np() {
    return make_2d_view(solver->heuristic_data(), solver->n, solver->k);
  }
  // py::array_t<int32_t> get_nn_pos() { ... } REMOVED

  py::array_t<int32_t> get_source_route() {
    return make_1d_view(solver->source_route.data(),
                        solver->source_route.size());
  }
  py::array_t<int32_t> get_best_route() {
    return make_1d_view(solver->best_route.data(), solver->best_route.size());
  }

  void seed_rng(uint64_t seed) { solver->seed_rng(seed); }

  py::tuple sample(bool require_prob = false, py::object prior = py::none(),
                   bool parallel_traced = false, bool return_decoded = false) {
    const float *prior_ptr = nullptr;
    py::array_t<float> prior_arr;

    if (!prior.is_none()) {
      prior_arr = prior.cast<
          py::array_t<float, py::array::c_style | py::array::forcecast>>();
      auto rbuf = prior_arr.request();
      if (rbuf.ndim != 2 || rbuf.shape[0] != solver->n ||
          rbuf.shape[1] != solver->k) {
        throw std::runtime_error("prior must be shape (n,k)");
      }
      prior_ptr = (const float *)rbuf.ptr;
    }

    SampleResult result;
    {
      py::gil_scoped_release release;
      solver->sample(require_prob, prior_ptr, result, parallel_traced);
    }

    py::array_t<float> costs(solver->n_ants);
    auto cb = costs.mutable_unchecked<1>();
    for (int32_t a = 0; a < solver->n_ants; ++a)
      cb(a) = result.costs[a];

    py::list routes;
    for (int32_t a = 0; a < solver->n_ants; ++a) {
      const auto &r = result.routes[a];
      py::array_t<int32_t> r_arr((py::ssize_t)r.size());
      auto rb = r_arr.mutable_unchecked<1>();
      for (size_t i = 0; i < r.size(); ++i)
        rb(i) = r[i];
      routes.append(r_arr);
    }

    py::object decoded_obj = py::none();
    if (return_decoded) {
      decoded_obj = routes;
    }

    py::object traces_obj = py::none();
    if (require_prob) {
      auto t = std::make_unique<PyMFACOTrace>();
      t->batch = std::move(result.traces);
      t->n_ants = solver->n_ants;
      traces_obj = py::cast(std::move(t));
    }

    py::array_t<float> costs_raw(solver->n_ants);
    if (!result.costs_raw.empty()) {
      auto cb = costs_raw.mutable_unchecked<1>();
      for (int32_t a = 0; a < solver->n_ants; ++a)
        cb(a) = result.costs_raw[a];
    }

    py::list perms_raw;
    if (!result.routes_raw.empty()) {
      for (int32_t a = 0; a < solver->n_ants; ++a) {
        if (!result.routes_raw[a].empty()) {
          const auto &r = result.routes_raw[a];
          py::array_t<int32_t> r_arr((py::ssize_t)r.size());
          auto rb = r_arr.mutable_unchecked<1>();
          for (size_t i = 0; i < r.size(); ++i)
            rb(i) = r[i];
          perms_raw.append(r_arr);
        } else {
          perms_raw.append(py::none());
        }
      }
    }

    py::array_t<float> logps_arr(solver->n_ants);
    if (!result.logps.empty()) {
      auto logps_buf = logps_arr.mutable_unchecked<1>();
      for (int32_t a = 0; a < solver->n_ants; ++a) {
        logps_buf(a) = result.logps[a];
      }
    }

    py::array_t<int32_t> new_edges_arr(solver->n_ants);
    auto ne_buf = new_edges_arr.mutable_unchecked<1>();
    if (!result.new_edges_count.empty()) {
      for (int32_t a = 0; a < solver->n_ants; ++a) {
        ne_buf(a) = result.new_edges_count[a];
      }
    } else {
      for (int32_t a = 0; a < solver->n_ants; ++a)
        ne_buf(a) = 0;
    }

    py::array_t<float> survival_arr(solver->n_ants);
    auto surv_buf = survival_arr.mutable_unchecked<1>();
    if (!result.edge_survival.empty()) {
      for (int32_t a = 0; a < solver->n_ants; ++a)
        surv_buf(a) = result.edge_survival[a];
    } else {
      for (int32_t a = 0; a < solver->n_ants; ++a)
        surv_buf(a) = 0.0f;
    }

    return py::make_tuple(costs, routes, decoded_obj, logps_arr, traces_obj,
                          costs_raw, perms_raw, new_edges_arr, survival_arr);
  }

  void update_pheromone_from_route(
      py::array_t<int32_t, py::array::c_style | py::array::forcecast>
          best_route,
      float best_cost) {
    auto buf = best_route.request();
    if (buf.ndim != 1) {
      throw std::runtime_error("best_route must be 1D");
    }
    const int32_t *p = (const int32_t *)buf.ptr;
    std::vector<int32_t> route_vec(p, p + buf.shape[0]);
    py::gil_scoped_release release;
    solver->update_pheromone(route_vec, best_cost);
  }

  void reset_timings() { solver->reset_timings(); }
  py::dict get_timings() {
    py::dict d;
    d["time_ant"] = solver->time_ant;
    d["time_ls"] = solver->time_ls;
    d["time_split"] = solver->time_split;
    return d;
  }
};

// ============================================================================
// ACO_TSP Python wrapper
// ============================================================================

class PyACO_TSP {
public:
  std::unique_ptr<ACO_TSP> solver;

  PyACO_TSP(
      py::array_t<float, py::array::c_style | py::array::forcecast> coords,
      int32_t n_ants, int32_t cand_list_size = 32, float decay = 0.9f,
      float alpha = 1.0f, float beta = 1.0f, float p_best = 0.05f,
      bool min_max = true) {
    auto buf = coords.request();
    if (buf.ndim != 2 || buf.shape[1] != 2) {
      throw std::runtime_error("coords must have shape (n, 2)");
    }
    int32_t n = static_cast<int32_t>(buf.shape[0]);
    const float *coords_ptr = static_cast<const float *>(buf.ptr);

    solver = std::make_unique<ACO_TSP>(coords_ptr, n, n_ants, cand_list_size,
                                       decay, alpha, beta, p_best, min_max);
  }

  // Properties
  int32_t get_n() const { return solver->n; }
  int32_t get_n_ants() const { return solver->n_ants; }
  int32_t get_k() const { return solver->k; }
  float get_rho() const { return solver->rho; }
  float get_alpha() const { return solver->alpha; }
  float get_beta() const { return solver->beta; } // New
  float get_p_best() const { return solver->p_best; }
  bool get_min_max() const { return solver->min_max; }
  float get_best_cost() const { return solver->best_cost; }
  float get_tau_min() const { return solver->tau_min; }
  float get_tau_max() const { return solver->tau_max; }

  py::array_t<float> get_pheromone_sparse_np() {
    return make_2d_view(solver->pheromone_data(), solver->n, solver->k);
  }
  py::array_t<int32_t> get_nn_list() {
    return make_2d_view(solver->nn_list_data(), solver->n, solver->k);
  }
  py::array_t<float> get_heuristic_sparse_np() {
    return make_2d_view(solver->heuristic_data(), solver->n, solver->k);
  }
  py::array_t<int32_t> get_best_route() {
    return make_1d_view(solver->best_route_data(), solver->n);
  }

  void seed_rng(uint64_t seed) { solver->seed_rng(seed); }

  py::tuple sample(bool require_prob = false, py::object prior_obj = py::none(),
                   bool parallel_traced = false) {
    const float *prior_ptr = nullptr;
    py::array_t<float> prior_arr;

    if (!prior_obj.is_none()) {
      prior_arr = prior_obj.cast<
          py::array_t<float, py::array::c_style | py::array::forcecast>>();
      auto buf = prior_arr.request();
      if (buf.ndim != 2 || buf.shape[0] != solver->n ||
          buf.shape[1] != solver->k) {
        throw std::runtime_error("prior must be shape (n, k)");
      }
      prior_ptr = static_cast<const float *>(buf.ptr);
    }

    SampleResult result;
    {
      py::gil_scoped_release release;
      solver->sample(require_prob, prior_ptr, result, parallel_traced);
    }

    py::array_t<float> costs(solver->n_ants);
    auto costs_buf = costs.mutable_unchecked<1>();
    for (int32_t a = 0; a < solver->n_ants; ++a)
      costs_buf(a) = result.costs[a];

    py::list flats;
    for (int32_t a = 0; a < solver->n_ants; ++a) {
      py::array_t<int32_t> flat(solver->n + 1);
      auto flat_buf = flat.mutable_unchecked<1>();
      for (int32_t i = 0; i < solver->n; ++i)
        flat_buf(i) = result.routes[a][i];
      flat_buf(solver->n) = result.routes[a][0];
      flats.append(flat);
    }

    // Convert traces to Python object
    py::object traces_obj = py::none();
    if (require_prob) {
      auto traces = std::make_unique<PyMFACOTrace>();
      traces->batch = std::move(result.traces);
      traces->n_ants = solver->n_ants;
      traces_obj = py::cast(std::move(traces));
    }

    py::array_t<float> logps_arr(solver->n_ants);
    if (!result.logps.empty()) {
      auto logps_buf = logps_arr.mutable_unchecked<1>();
      for (int32_t a = 0; a < solver->n_ants; ++a)
        logps_buf(a) = result.logps[a];
    }

    // Return signature compatible with MFACO
    return py::make_tuple(costs, flats, py::none(), logps_arr, traces_obj,
                          py::none(), py::none(), py::none(), py::none());
  }

  void update_pheromone(
      py::array_t<int32_t, py::array::c_style | py::array::forcecast> solution,
      float cost) {
    auto buf = solution.request();
    if (buf.ndim != 1 || buf.shape[0] < solver->n) {
      throw std::runtime_error("solution must be at least length n");
    }
    const int32_t *ptr = static_cast<const int32_t *>(buf.ptr);
    py::gil_scoped_release release;
    solver->update_pheromone(ptr, cost);
  }
};

// ============================================================================
// ACO_CVRP Python wrapper
// ============================================================================

class PyACO_CVRP {
public:
  std::unique_ptr<ACO_CVRP> solver;

  PyACO_CVRP(
      py::array_t<float, py::array::c_style | py::array::forcecast> coords,
      py::array_t<float, py::array::c_style | py::array::forcecast> demand,
      float capacity, int32_t n_ants, int32_t cand_list_size = 0,
      float decay = 0.9f, float alpha = 1.0f, float beta = 1.0f,
      float p_best = 0.05f, bool min_max = true, bool elitist = false,
      bool use_local_search = false) {

    auto cbuf = coords.request();
    if (cbuf.ndim != 2 || cbuf.shape[1] != 2) {
      throw std::runtime_error("coords must have shape (n, 2)");
    }
    int32_t n = static_cast<int32_t>(cbuf.shape[0]);
    const float *coords_ptr = static_cast<const float *>(cbuf.ptr);

    auto dbuf = demand.request();
    if (dbuf.ndim != 1 || dbuf.shape[0] != n) {
      throw std::runtime_error("demand must have shape (n,)");
    }
    const float *demand_ptr = static_cast<const float *>(dbuf.ptr);

    solver = std::make_unique<ACO_CVRP>(
        coords_ptr, demand_ptr, n, capacity, n_ants, cand_list_size, decay,
        alpha, beta, p_best, min_max, elitist, use_local_search);
  }

  // Properties
  int32_t get_n() const { return solver->n; }
  int32_t get_n_ants() const { return solver->n_ants; }
  int32_t get_k() const { return solver->k; }
  float get_capacity() const { return solver->capacity; }
  float get_rho() const { return solver->rho; }
  float get_alpha() const { return solver->alpha; }
  float get_beta() const { return solver->beta; }
  float get_p_best() const { return solver->p_best; }
  bool get_min_max() const { return solver->min_max; }
  float get_best_cost() const { return solver->best_cost; }
  float get_tau_min() const { return solver->tau_min; }
  float get_tau_max() const { return solver->tau_max; }

  py::array_t<float> get_pheromone_sparse_np() {
    return make_2d_view(solver->pheromone_data(), solver->n, solver->k);
  }
  py::array_t<int32_t> get_nn_list() {
    return make_2d_view(solver->nn_list_data(), solver->n, solver->k);
  }
  py::array_t<float> get_heuristic_sparse_np() {
    return make_2d_view(solver->heuristic_data(), solver->n, solver->k);
  }
  // best_route varies in length. Return copy.
  py::array_t<int32_t> get_best_route() {
    std::vector<int32_t> rt = solver->get_best_route();
    return make_1d_view(rt.data(), rt.size());
    // Warning: rt.data() is temporary vector data if get_best_route returns by
    // value! Fix: solver->get_best_route() returns a vector copy. make_1d_view
    // wraps POINTER. If vector dies, pointer invalid. We MUST copy to new numpy
    // array. make_1d_view approach relies on underlying data persisting? Wait,
    // existing make_1d_view uses make_view which creates array_t with pointer.
    // Does it copy? "py::array_t<T>(shape, strides, data, py::none())"
    // If owner is none, it does NOT manage memory? It creates a VIEW?
    // Yes, creating a view over C++ memory.
    // `solver->best_route` persists so `solver->best_route_data()` works.
    // But `ACO_CVRP::get_best_route()` returned by value in my header def?
    // Header: `std::vector<int32_t> get_best_route() const { return best_route;
    // }` -> Returns copy! So using `get_best_route().data()` is unsafe if view
    // is created. I should expose `best_route` pointer directly from solver or
    // change `get_best_route` to return reference. Or just manually copy in
    // binding.
  }

  py::array_t<int32_t> get_best_route_copy() {
    // Helper to return copy
    std::vector<int32_t> rt = solver->best_route; // Copy from solver state
    py::array_t<int32_t> result(rt.size());
    auto buf = result.mutable_unchecked<1>();
    for (size_t i = 0; i < rt.size(); ++i)
      buf(i) = rt[i];
    return result;
  }

  void seed_rng(uint64_t seed) { solver->seed_rng(seed); }

  py::tuple sample(bool require_prob = false, py::object prior_obj = py::none(),
                   bool parallel_traced = false) {
    const float *prior_ptr = nullptr;
    py::array_t<float> prior_arr;

    if (!prior_obj.is_none()) {
      prior_arr = prior_obj.cast<
          py::array_t<float, py::array::c_style | py::array::forcecast>>();
      auto buf = prior_arr.request();
      if (buf.ndim != 2 || buf.shape[0] != solver->n ||
          buf.shape[1] != solver->k) {
        throw std::runtime_error("prior must be shape (n, k)");
      }
      prior_ptr = static_cast<const float *>(buf.ptr);
    }

    SampleResult result;
    {
      py::gil_scoped_release release;
      solver->sample(require_prob, prior_ptr, result, parallel_traced);
    }

    py::array_t<float> costs(solver->n_ants);
    auto costs_buf = costs.mutable_unchecked<1>();
    for (int32_t a = 0; a < solver->n_ants; ++a)
      costs_buf(a) = result.costs[a];

    // Routes in CVRP (giant tour format with depots)
    py::list routes;
    for (int32_t a = 0; a < solver->n_ants; ++a) {
      // Copy vector to numpy
      const auto &r = result.routes[a];
      py::array_t<int32_t> r_arr(r.size());
      auto rb = r_arr.mutable_unchecked<1>();
      for (size_t i = 0; i < r.size(); ++i)
        rb(i) = r[i];
      routes.append(r_arr);
    }

    // Convert traces to Python object
    py::object traces_obj = py::none();
    if (require_prob) {
      auto traces = std::make_unique<PyMFACOTrace>();
      traces->batch = std::move(result.traces);
      traces->n_ants = solver->n_ants;
      traces_obj = py::cast(std::move(traces));
    }

    py::array_t<float> logps_arr(solver->n_ants);
    if (!result.logps.empty()) {
      auto logps_buf = logps_arr.mutable_unchecked<1>();
      for (int32_t a = 0; a < solver->n_ants; ++a)
        logps_buf(a) = result.logps[a];
    }

    // Return tuple matching MFACO signature
    return py::make_tuple(costs, routes, py::none(), logps_arr, traces_obj,
                          py::none(), py::none(), py::none(), py::none());
  }

  void update_pheromone(
      py::array_t<int32_t, py::array::c_style | py::array::forcecast> solution,
      float cost) {
    auto buf = solution.request();
    if (buf.ndim != 1)
      throw std::runtime_error("solution must be 1D");
    const int32_t *ptr = static_cast<const int32_t *>(buf.ptr);
    int32_t len = static_cast<int32_t>(buf.shape[0]);

    py::gil_scoped_release release;
    solver->update_pheromone(ptr, len, cost);
  }
};

// ============================================================================
// Module definition
// ============================================================================

PYBIND11_MODULE(faco_opt, m) {
  m.doc() = "Unified C++ MFACO Training Module for TSP and CVRP";

  // OpenMP controls
  m.def(
      "set_num_threads",
      [](int n_threads) {
        if (n_threads <= 0)
          throw std::runtime_error("n_threads must be > 0");
        omp_set_num_threads(n_threads);
      },
      py::arg("n_threads"), "Set OpenMP thread count");

  m.def("get_max_threads", []() { return omp_get_max_threads(); });
  m.def("get_num_procs", []() { return omp_get_num_procs(); });
  m.def(
      "set_dynamic", [](bool enabled) { omp_set_dynamic(enabled ? 1 : 0); },
      py::arg("enabled"));
  m.def("get_dynamic", []() { return omp_get_dynamic() != 0; });

  // MFACOTrace
  py::class_<PyMFACOTrace>(m, "MFACOTrace")
      .def(py::init<>())
      .def_property_readonly("starts", &PyMFACOTrace::get_starts)
      .def_property_readonly("curr_nodes", &PyMFACOTrace::get_curr_nodes)
      .def_property_readonly("chosen_nodes", &PyMFACOTrace::get_chosen_nodes)
      .def_property_readonly("is_stochastic", &PyMFACOTrace::get_is_stochastic)
      .def_property_readonly("pick_j", &PyMFACOTrace::get_pick_j)
      .def_property_readonly("valid_mask", &PyMFACOTrace::get_valid_mask)
      .def_property_readonly("is_new_edge", &PyMFACOTrace::get_is_new_edge)
      .def_property_readonly("start_nodes", &PyMFACOTrace::get_start_nodes)
      .def_property_readonly("n_decisions", &PyMFACOTrace::n_decisions)
      .def_property_readonly("n_ants",
                             [](const PyMFACOTrace &t) { return t.n_ants; })
      .def("to_trace_list", &PyMFACOTrace::to_trace_list);

  // MFACO_TSP
  py::class_<PyMFACO_TSP>(m, "MFACO_TSP")
      .def(py::init<
               py::array_t<float, py::array::c_style | py::array::forcecast>,
               int32_t, int32_t, int32_t, int32_t, float, float, float, bool,
               bool, bool, bool, int32_t, bool, int32_t>(),
           py::arg("coords"), py::arg("n_ants"), py::arg("cand_list_size") = 32,
           py::arg("backup_list_size") = 32, py::arg("min_new_edges") = 8,
           py::arg("decay") = 0.9f, py::arg("alpha") = 1.0f,
           py::arg("p_best") = 0.05f, py::arg("use_local_search") = true,
           py::arg("disable_heuristic") = false, py::arg("extend_ls") = false,
           py::arg("smooth_mmas") = false, py::arg("fixed_steps") = 0,
           py::arg("nls") = false, py::arg("T_nls") = 10)
      .def_property_readonly("n", &PyMFACO_TSP::get_n)
      .def_property_readonly("n_ants", &PyMFACO_TSP::get_n_ants)
      .def_property_readonly("k", &PyMFACO_TSP::get_k)
      .def_property_readonly("bl", &PyMFACO_TSP::get_bl)
      .def_property_readonly("min_new_edges", &PyMFACO_TSP::get_min_new_edges)
      .def_property_readonly("fixed_steps", &PyMFACO_TSP::get_fixed_steps)
      .def_property_readonly("rho", &PyMFACO_TSP::get_rho)
      .def_property_readonly("alpha", &PyMFACO_TSP::get_alpha)
      .def_property_readonly("p_best", &PyMFACO_TSP::get_p_best)
      .def_property_readonly("use_local_search",
                             &PyMFACO_TSP::get_use_local_search)
      .def_property_readonly("extend_ls", &PyMFACO_TSP::get_extend_ls)
      .def_property_readonly("smooth_mmas", &PyMFACO_TSP::get_smooth_mmas)
      .def_property_readonly("source_cost", &PyMFACO_TSP::get_source_cost)
      .def_property_readonly("best_cost", &PyMFACO_TSP::get_best_cost)
      .def_property_readonly("tau_min", &PyMFACO_TSP::get_tau_min)
      .def_property_readonly("tau_max", &PyMFACO_TSP::get_tau_max)
      .def_property_readonly("pheromone_sparse_np",
                             &PyMFACO_TSP::get_pheromone_sparse_np)
      .def_property_readonly("nn_list", &PyMFACO_TSP::get_nn_list)
      .def_property_readonly("backup_list", &PyMFACO_TSP::get_backup_list)
      .def_property_readonly("heuristic_sparse_np",
                             &PyMFACO_TSP::get_heuristic_sparse_np)
      .def_property_readonly("source_route", &PyMFACO_TSP::get_source_route)
      .def_property_readonly("best_route", &PyMFACO_TSP::get_best_route)
      .def_property_readonly("best_route", &PyMFACO_TSP::get_best_route)
      // .def_property_readonly("nn_pos", &PyMFACO_TSP::get_nn_pos)
      .def_property_readonly("source_positions",
                             &PyMFACO_TSP::get_source_positions)
      .def("seed_rng", &PyMFACO_TSP::seed_rng, py::arg("seed"))
      .def("set_ls_widths", &PyMFACO_TSP::set_ls_widths, py::arg("widths"))
      .def("enable_ls_counts", &PyMFACO_TSP::enable_ls_counts, py::arg("enabled"))
      .def("get_ls_counts", &PyMFACO_TSP::get_ls_counts)
      .def("get_ls_state", &PyMFACO_TSP::get_ls_state)
      .def("sample", &PyMFACO_TSP::sample, py::arg("invtemp") = 1.0f,
           py::arg("require_prob") = false, py::arg("prior") = py::none(),
           py::arg("parallel_traced") = false)
      .def("_update_pheromone_from_flat",
           &PyMFACO_TSP::update_pheromone_from_flat)
      .def("load_snapshot", &PyMFACO_TSP::load_snapshot)
      .def("set_pheromone", &PyMFACO_TSP::set_pheromone)
      .def("sync_pheromone_to_torch", &PyMFACO_TSP::sync_pheromone_to_torch);

  // MFACO_CVRP
  py::class_<PyMFACO_CVRP>(m, "MFACO_CVRP")
      .def(py::init<
               py::array_t<float, py::array::c_style | py::array::forcecast>,
               py::array_t<float, py::array::c_style | py::array::forcecast>,
               float, int32_t, int32_t, int32_t, int32_t, float, float, float,
               bool, bool, bool, bool, int32_t, bool, int32_t>(),
           py::arg("coords"), py::arg("demand"), py::arg("capacity"),
           py::arg("n_ants"), py::arg("cand_list_size") = 32,
           py::arg("backup_list_size") = 32, py::arg("min_new_edges") = 8,
           py::arg("decay") = 0.9f, py::arg("alpha") = 1.0f,
           py::arg("p_best") = 0.05f, py::arg("use_local_search") = true,
           py::arg("disable_heuristic") = false, py::arg("extend_ls") = false,
           py::arg("smooth_mmas") = false, py::arg("fixed_steps") = 0,
           py::arg("nls") = false, py::arg("T_nls") = 10)
      .def_property_readonly("n", &PyMFACO_CVRP::get_n)
      .def_property_readonly("m", &PyMFACO_CVRP::get_m)
      .def_property_readonly("n_ants", &PyMFACO_CVRP::get_n_ants)
      .def_property_readonly("k", &PyMFACO_CVRP::get_k)
      .def_property_readonly("bl", &PyMFACO_CVRP::get_bl)
      .def_property_readonly("source_cost", &PyMFACO_CVRP::get_source_cost)
      .def_property_readonly("best_cost", &PyMFACO_CVRP::get_best_cost)
      .def_property_readonly("tau_min", &PyMFACO_CVRP::get_tau_min)
      .def_property_readonly("tau_max", &PyMFACO_CVRP::get_tau_max)
      .def_property_readonly("pheromone_sparse_np",
                             &PyMFACO_CVRP::get_pheromone_sparse_np)
      .def_property_readonly("nn_list", &PyMFACO_CVRP::get_nn_list)
      .def_property_readonly("backup_list", &PyMFACO_CVRP::get_backup_list)
      .def_property_readonly("heuristic_sparse_np",
                             &PyMFACO_CVRP::get_heuristic_sparse_np)
      .def_property_readonly("heuristic_sparse_np",
                             &PyMFACO_CVRP::get_heuristic_sparse_np)
      // .def_property_readonly("nn_pos", &PyMFACO_CVRP::get_nn_pos)
      .def_property_readonly("source_route", &PyMFACO_CVRP::get_source_route)
      .def_property_readonly("best_route", &PyMFACO_CVRP::get_best_route)
      .def("seed_rng", &PyMFACO_CVRP::seed_rng)
      .def("sample", &PyMFACO_CVRP::sample, py::arg("require_prob") = false,
           py::arg("prior") = py::none(), py::arg("parallel_traced") = false,
           py::arg("return_decoded") = false)
      .def("update_pheromone_from_route",
           &PyMFACO_CVRP::update_pheromone_from_route)
      .def_property(
          "use_relocate",
          [](PyMFACO_CVRP &self) { return self.solver->use_relocate; },
          [](PyMFACO_CVRP &self, bool v) { self.solver->use_relocate = v; })
      .def_property(
          "use_swap", [](PyMFACO_CVRP &self) { return self.solver->use_swap; },
          [](PyMFACO_CVRP &self, bool v) { self.solver->use_swap = v; })
      .def_property(
          "use_2opt_star",
          [](PyMFACO_CVRP &self) { return self.solver->use_2opt_star; },
          [](PyMFACO_CVRP &self, bool v) { self.solver->use_2opt_star = v; })
      .def("reset_timings", &PyMFACO_CVRP::reset_timings)
      .def("get_timings", &PyMFACO_CVRP::get_timings);

  // ACO_TSP
  py::class_<PyACO_TSP>(m, "ACO_TSP")
      .def(py::init<
               py::array_t<float, py::array::c_style | py::array::forcecast>,
               int32_t, int32_t, float, float, float, float, bool>(),
           py::arg("coords"), py::arg("n_ants"), py::arg("cand_list_size") = 32,
           py::arg("decay") = 0.9f, py::arg("alpha") = 1.0f,
           py::arg("beta") = 1.0f, py::arg("p_best") = 0.05f,
           py::arg("min_max") = true)
      .def_property_readonly("n", &PyACO_TSP::get_n)
      .def_property_readonly("n_ants", &PyACO_TSP::get_n_ants)
      .def_property_readonly("k", &PyACO_TSP::get_k)
      .def_property_readonly("rho", &PyACO_TSP::get_rho)
      .def_property_readonly("alpha", &PyACO_TSP::get_alpha)
      .def_property_readonly("beta", &PyACO_TSP::get_beta)
      .def_property_readonly("p_best", &PyACO_TSP::get_p_best)
      .def_property_readonly("min_max", &PyACO_TSP::get_min_max)
      .def_property_readonly("best_cost", &PyACO_TSP::get_best_cost)
      .def_property_readonly("tau_min", &PyACO_TSP::get_tau_min)
      .def_property_readonly("tau_max", &PyACO_TSP::get_tau_max)
      .def_property_readonly("pheromone_sparse_np",
                             &PyACO_TSP::get_pheromone_sparse_np)
      .def_property_readonly("nn_list", &PyACO_TSP::get_nn_list)
      .def_property_readonly("heuristic_sparse_np",
                             &PyACO_TSP::get_heuristic_sparse_np)
      .def_property_readonly("best_route", &PyACO_TSP::get_best_route)
      .def("seed_rng", &PyACO_TSP::seed_rng, py::arg("seed"))
      .def("sample", &PyACO_TSP::sample, py::arg("require_prob") = false,
           py::arg("prior") = py::none(), py::arg("parallel_traced") = false)
      .def("update_pheromone", &PyACO_TSP::update_pheromone);

  // ACO_CVRP
  py::class_<PyACO_CVRP>(m, "ACO_CVRP")
      .def(py::init<
               py::array_t<float, py::array::c_style | py::array::forcecast>,
               py::array_t<float, py::array::c_style | py::array::forcecast>,
               float, int32_t, int32_t, float, float, float, float, bool, bool,
               bool>(),
           py::arg("coords"), py::arg("demand"), py::arg("capacity"),
           py::arg("n_ants"), py::arg("cand_list_size") = 0,
           py::arg("decay") = 0.9f, py::arg("alpha") = 1.0f,
           py::arg("beta") = 1.0f, py::arg("p_best") = 0.05f,
           py::arg("min_max") = true, py::arg("elitist") = false,
           py::arg("use_local_search") = false)
      .def_property_readonly("n", &PyACO_CVRP::get_n)
      .def_property_readonly("n_ants", &PyACO_CVRP::get_n_ants)
      .def_property_readonly("k", &PyACO_CVRP::get_k)
      .def_property_readonly("capacity", &PyACO_CVRP::get_capacity)
      .def_property_readonly("rho", &PyACO_CVRP::get_rho)
      .def_property_readonly("alpha", &PyACO_CVRP::get_alpha)
      .def_property_readonly("beta", &PyACO_CVRP::get_beta)
      .def_property_readonly("p_best", &PyACO_CVRP::get_p_best)
      .def_property_readonly("min_max", &PyACO_CVRP::get_min_max)
      .def_property_readonly("best_cost", &PyACO_CVRP::get_best_cost)
      .def_property_readonly("tau_min", &PyACO_CVRP::get_tau_min)
      .def_property_readonly("tau_max", &PyACO_CVRP::get_tau_max)
      .def_property_readonly("pheromone_sparse_np",
                             &PyACO_CVRP::get_pheromone_sparse_np)
      .def_property_readonly("nn_list", &PyACO_CVRP::get_nn_list)
      .def_property_readonly("heuristic_sparse_np",
                             &PyACO_CVRP::get_heuristic_sparse_np)
      .def_property_readonly("best_route", &PyACO_CVRP::get_best_route_copy)
      .def("seed_rng", &PyACO_CVRP::seed_rng, py::arg("seed"))
      .def("sample", &PyACO_CVRP::sample, py::arg("require_prob") = false,
           py::arg("prior") = py::none(), py::arg("parallel_traced") = false)
      .def("update_pheromone", &PyACO_CVRP::update_pheromone);
}
